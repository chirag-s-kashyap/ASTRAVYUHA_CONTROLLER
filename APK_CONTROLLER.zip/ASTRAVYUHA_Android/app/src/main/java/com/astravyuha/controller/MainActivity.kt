package com.astravyuha.controller

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(9, 10, 13)
    private val panel = Color.rgb(19, 20, 24)
    private val panel2 = Color.rgb(29, 29, 32)
    private val gold = Color.rgb(214, 179, 106)
    private val cream = Color.rgb(241, 229, 204)
    private val muted = Color.rgb(151, 145, 132)
    private val red = Color.rgb(166, 57, 48)
    private val green = Color.rgb(89, 155, 112)
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val sendBusy = AtomicBoolean(false)
    private var baseUrl = ""
    private var pin = ""
    private var token = ""
    private var player = 0
    private var seq = 0
    private var bits = 0
    private var ax = 0
    private var ay = 0
    private var phase = "menu"
    private var selected = ""
    private var hud = JSONObject()
    private var lastResult = ""
    private var currentScreen = "splash"
    private var root: FrameLayout? = null
    private var statusText: TextView? = null
    private var resultTitle: TextView? = null
    private var preview: PreviewView? = null
    private var scannerStarted = false
    private var lastHudSignature = ""
    private var ownBar: ProgressBar? = null
    private var oppBar: ProgressBar? = null
    private var ownHpText: TextView? = null
    private var oppHpText: TextView? = null
    private val fighters = listOf(
        Fighter("viraksha", "VIRAKSHA", R.drawable.viraksha_portrait),
        Fighter("mrinala", "MRINALA", R.drawable.mrinala_portrait),
        Fighter("ketuman", "KETUMAN", R.drawable.ketuman_portrait),
        Fighter("karkati", "KARKATI", R.drawable.karkati_portrait),
        Fighter("aranyak", "ARANYAK", R.drawable.aranyak_portrait),
        Fighter("sharvan", "SHARVAN", R.drawable.sharvan_portrait),
        Fighter("tamrini", "TAMRINI", R.drawable.tamrini_portrait),
        Fighter("nirvay", "NIRVAY", R.drawable.nirvay_portrait)
    )

    data class Fighter(val id: String, val title: String, val portrait: Int)

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startScannerCamera() else showManualConnect("Camera permission is needed to scan the game's QR code.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        showSplash()
        main.postDelayed({ if (currentScreen == "splash") openScanner() }, 1450)
    }

    override fun onDestroy() {
        stopInput()
        io.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float, color: Int = cream, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = false
    }
    private fun card(view: View, color: Int = panel, radius: Float = 14f) {
        view.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius.toInt()).toFloat(); setStroke(dp(1), Color.rgb(70, 61, 45))
        }
    }
    private fun baseRoot(): FrameLayout {
        val f = FrameLayout(this).apply { setBackgroundColor(bg) }
        root = f; setContentView(f); return f
    }
    private fun showSplash() {
        currentScreen = "splash"
        val r = baseRoot()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val sigil = text("✦", 30f, gold, true)
        val logo = ImageView(this).apply { setImageResource(R.drawable.astra_logo); scaleType = ImageView.ScaleType.FIT_CENTER }
        val sub = text("THE ART OF WAR", 11f, muted, true).apply { letterSpacing = .32f }
        val line = View(this).apply { setBackgroundColor(gold) }
        box.addView(sigil); box.addView(logo, LinearLayout.LayoutParams(dp(330), dp(76)))
        box.addView(line, LinearLayout.LayoutParams(dp(150), dp(1)).apply { gravity = Gravity.CENTER; topMargin = dp(8); bottomMargin = dp(10) })
        box.addView(sub)
        r.addView(box, FrameLayout.LayoutParams(-1, -1))
    }

    private fun openScanner() {
        currentScreen = "scanner"
        val r = baseRoot()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(20), dp(16), dp(20), dp(16)) }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(20), 0) }
        left.addView(text("ASTRAVYUHA", 24f, gold, true), LinearLayout.LayoutParams(-1, dp(40)))
        left.addView(text("CONTROLLER LINK", 11f, muted, true), LinearLayout.LayoutParams(-1, dp(24)))
        left.addView(text("SCAN THE QR CODE\nDISPLAYED ON YOUR GAME SCREEN", 18f, cream, true).apply { gravity = Gravity.START; setLineSpacing(dp(7).toFloat(), 1f) }, LinearLayout.LayoutParams(-1, dp(90)))
        left.addView(text("Connect your phone and PC to the same Wi-Fi network.", 13f, muted).apply { gravity = Gravity.START }, LinearLayout.LayoutParams(-1, dp(48)))
        val manual = makeButton("ENTER ADDRESS + PIN", panel2, gold) { showManualConnect() }
        left.addView(manual, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(18) })
        val scanWrap = FrameLayout(this).apply { card(this, panel, 18f) }
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        scanWrap.addView(preview, FrameLayout.LayoutParams(-1, -1))
        val scanLabel = text("CAMERA SCANNER", 11f, gold, true).apply {
            setBackgroundColor(Color.argb(190, 9, 10, 13)); setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        scanWrap.addView(scanLabel, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(12) })
        row.addView(left, LinearLayout.LayoutParams(0, -1, 1.1f))
        row.addView(scanWrap, LinearLayout.LayoutParams(0, -1, .9f))
        r.addView(row, FrameLayout.LayoutParams(-1, -1))
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startScannerCamera()
        else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startScannerCamera() {
        if (scannerStarted || currentScreen != "scanner") return
        scannerStarted = true
        val pv = preview ?: return
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val p = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                val scanner = BarcodeScanning.getClient()
                analysis.setAnalyzer(Executors.newSingleThreadExecutor()) { proxy ->
                    val media = proxy.image
                    if (media == null) { proxy.close(); return@setAnalyzer }
                    val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    scanner.process(image).addOnSuccessListener { codes ->
                        val raw = codes.firstOrNull { it.rawValue?.startsWith("http") == true }?.rawValue
                        if (raw != null) main.post { handleQr(raw) }
                    }.addOnCompleteListener { proxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, p, analysis)
            } catch (_: Exception) { main.post { showManualConnect("Unable to start camera. Enter the game address and PIN instead.") } }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun handleQr(raw: String) {
        if (currentScreen != "scanner") return
        try {
            val uri = Uri.parse(raw)
            val host = uri.host ?: return
            val port = if (uri.port > 0) uri.port else 80
            val foundPin = uri.getQueryParameter("pin") ?: return
            baseUrl = "http://$host:$port"
            pin = foundPin
            scannerStarted = false
            joinGame()
        } catch (_: Exception) { }
    }

    private fun showManualConnect(message: String = "") {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(18), dp(24), dp(8)) }
        layout.addView(text("CONNECT TO YOUR GAME", 19f, gold, true), LinearLayout.LayoutParams(-1, dp(42)))
        if (message.isNotBlank()) layout.addView(text(message, 12f, muted))
        val address = EditText(this).apply { hint = "PC address, e.g. 192.168.1.20:8765"; setSingleLine(); setTextColor(cream); setHintTextColor(muted); setBackgroundColor(panel2); setPadding(dp(12), 0, dp(12), 0) }
        val pinInput = EditText(this).apply { hint = "4-digit game PIN"; setSingleLine(); inputType = android.text.InputType.TYPE_CLASS_NUMBER; setTextColor(cream); setHintTextColor(muted); setBackgroundColor(panel2); setPadding(dp(12), 0, dp(12), 0) }
        layout.addView(address, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(12) })
        layout.addView(pinInput, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        val dialog = android.app.AlertDialog.Builder(this).setView(layout).setNegativeButton("BACK", null).setPositiveButton("CONNECT", null).create()
        dialog.setOnShowListener {
            dialog.getButton(-1).setTextColor(gold)
            dialog.getButton(-1).setOnClickListener {
                val raw = address.text.toString().trim().removePrefix("http://").removePrefix("https://").trimEnd('/')
                val p = pinInput.text.toString().trim()
                if (raw.isBlank() || p.isBlank()) { pinInput.error = "Enter the address and PIN"; return@setOnClickListener }
                baseUrl = "http://$raw"; pin = p; dialog.dismiss(); joinGame()
            }
        }
        dialog.show()
    }

    private fun joinGame() {
        currentScreen = "joining"
        val r = baseRoot()
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        v.addView(text("ESTABLISHING LINK", 23f, gold, true))
        v.addView(text("PAIRING WITH ASTRAVYUHA · PLAYER SLOT AUTO", 11f, muted).apply { setPadding(0, dp(14), 0, 0) })
        r.addView(v, FrameLayout.LayoutParams(-1, -1))
        io.execute {
            try {
                val body = JSONObject().put("pin", pin).put("slot", 0).put("name", "ASTRAVYUHA Android")
                if (token.isNotBlank()) body.put("token", token)
                val response = request("POST", "/api/join", body)
                if (response.optBoolean("ok")) {
                    token = response.getString("token"); player = response.getInt("player")
                    getSharedPreferences("astra", MODE_PRIVATE).edit().putString("base", baseUrl).putString("pin", pin).putString("token", token).putInt("player", player).apply()
                    seq = 0
                    main.post { buildController(); startInput() }
                } else main.post { currentScreen = "scanner"; openScanner(); Toast.makeText(this, response.optString("error", "Could not connect"), Toast.LENGTH_LONG).show() }
            } catch (e: Exception) { main.post { currentScreen = "scanner"; openScanner(); Toast.makeText(this, "Connection failed: ${e.message ?: "check same Wi-Fi"}", Toast.LENGTH_LONG).show() } }
        }
    }

    private fun buildController() {
        currentScreen = "controller"
        val r = baseRoot()
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(10)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = text("ASTRAVYUHA", 18f, gold, true).apply { letterSpacing = .1f; gravity = Gravity.CENTER_VERTICAL }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(34), 1f))
        statusText = text("CONNECTED · PLAYER $player", 11f, green, true)
        top.addView(statusText, LinearLayout.LayoutParams(-2, dp(34)))
        val leave = makeButton("EXIT", panel2, muted) { disconnect(true) }
        top.addView(leave, LinearLayout.LayoutParams(dp(72), dp(34)).apply { leftMargin = dp(12) })
        column.addView(top, LinearLayout.LayoutParams(-1, dp(40)))
        val divider = View(this).apply { setBackgroundColor(Color.rgb(77, 63, 42)) }
        column.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        val stage = FrameLayout(this)
        column.addView(stage, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        r.addView(column, FrameLayout.LayoutParams(-1, -1))
        renderPhase(stage)
    }

    private fun renderPhase(stage: FrameLayout) {
        stage.removeAllViews()
        val isSelect = phase == "menu" || phase == "setup"
        if (isSelect) renderSelection(stage) else if (phase == "results" || lastResult.isNotBlank()) renderResults(stage) else renderFight(stage)
    }

    private fun renderSelection(stage: FrameLayout) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(3), dp(6), dp(3)) }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        heading.addView(text("CHOOSE YOUR WARRIOR", 18f, cream, true), LinearLayout.LayoutParams(0, dp(34), 1f))
        heading.addView(text("PLAYER $player  ·  8 FIGHTERS", 11f, gold, true))
        wrap.addView(heading)
        val grid = android.widget.GridLayout(this).apply { columnCount = 4; rowCount = 2; useDefaultMargins = false }
        fighters.forEach { fighter ->
            val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(5), dp(4), dp(5), dp(4)) }
            val selectedNow = selected == fighter.id
            card(tile, if (selectedNow) Color.rgb(54, 43, 27) else panel, 10f)
            val img = ImageView(this).apply { setImageResource(fighter.portrait); scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.rgb(14, 14, 17)) }
            tile.addView(img, LinearLayout.LayoutParams(-1, 0, 1f))
            val name = text(fighter.title, 11f, if (selectedNow) gold else cream, true)
            tile.addView(name, LinearLayout.LayoutParams(-1, dp(26)))
            tile.setOnClickListener { selectFighter(fighter) }
            val lp = android.widget.GridLayout.LayoutParams().apply { width = 0; height = 0; columnSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f); rowSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f); setMargins(dp(4), dp(4), dp(4), dp(4)) }
            grid.addView(tile, lp)
        }
        wrap.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(5) })
        wrap.addView(text(if (selected.isBlank()) "TAP A PORTRAIT TO LOCK YOUR FIGHTER" else "${selected.uppercase()}  ·  LOCKED IN", 10f, gold, true), LinearLayout.LayoutParams(-1, dp(24)))
        stage.addView(wrap, FrameLayout.LayoutParams(-1, -1))
    }

    private fun renderFight(stage: FrameLayout) {
        val area = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), 0, dp(8), 0) }
        val fighterName = hud.optString("name", "PLAYER $player").ifBlank { "PLAYER $player" }
        val opp = hud.optString("opp_name", "OPPONENT").ifBlank { "OPPONENT" }
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        stats.addView(statBlock(fighterName.uppercase(), hud.optInt("hp", 0), hud.optInt("hp_max", 100), true), LinearLayout.LayoutParams(0, dp(55), 1f))
        stats.addView(statBlock(opp.uppercase(), hud.optInt("opp_hp", 0), hud.optInt("opp_hp_max", 100), false), LinearLayout.LayoutParams(0, dp(55), 1f))
        left.addView(stats, LinearLayout.LayoutParams(-1, dp(58)))
        val stick = JoystickView(this) { x, y -> ax = x; ay = y }
        left.addView(stick, LinearLayout.LayoutParams(dp(230), 0, 1f).apply { gravity = Gravity.CENTER; topMargin = dp(5) })
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), 0, dp(4), 0) }
        val buttons = android.widget.GridLayout(this).apply { columnCount = 3; rowCount = 2; useDefaultMargins = false }
        val actions = listOf("JUMP" to 1, "LIGHT" to 2, "HEAVY" to 4, "BLOCK" to 8, "EVADE" to 16, "ASTRA" to 32)
        actions.forEachIndexed { index, pair ->
            val b = ActionPad(this, pair.first, if (pair.second == 32) gold else if (pair.second == 4) red else panel2) { down ->
                if (down) bits = bits or pair.second else bits = bits and pair.second.inv()
                if (down) vibrate(12)
            }
            val lp = android.widget.GridLayout.LayoutParams().apply { width = 0; height = 0; columnSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f); rowSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f); setMargins(dp(5), dp(5), dp(5), dp(5)) }
            buttons.addView(b, lp)
        }
        right.addView(buttons, LinearLayout.LayoutParams(-1, 0, 1f))
        val meter = hud.optInt("meter", 0); val meterMax = hud.optInt("meter_max", 100)
        right.addView(text("ASTRA METER  $meter / ${if (meterMax > 0) meterMax else 100}", 10f, gold, true), LinearLayout.LayoutParams(-1, dp(24)))
        area.addView(left, LinearLayout.LayoutParams(0, -1, 1f))
        area.addView(right, LinearLayout.LayoutParams(0, -1, 1f))
        stage.addView(area, FrameLayout.LayoutParams(-1, -1))
    }

    private fun statBlock(name: String, hp: Int, maxHp: Int, own: Boolean): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(4), dp(8), dp(4)) }
        box.addView(text(name, 10f, cream, true))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = if (maxHp > 0) maxHp else 100; progress = hp.coerceIn(0, max); progressTintList = android.content.res.ColorStateList.valueOf(if (hp < max / 4) red else gold)
        }
        if (own) ownBar = bar else oppBar = bar
        box.addView(bar, LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(5) })
        val hpText = text("$hp / ${if (maxHp > 0) maxHp else 100}", 9f, muted)
        if (own) ownHpText = hpText else oppHpText = hpText
        box.addView(hpText)
        return box
    }

    private fun renderResults(stage: FrameLayout) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val won = lastResult == "win" || hud.optString("match_state").contains("win", true)
        box.addView(text(if (won) "VICTORY" else "DEFEAT", 36f, if (won) gold else Color.rgb(190, 100, 89), true))
        box.addView(text("ROUND ${hud.optInt("round", 1)}  ·  ${hud.optString("name", "PLAYER $player")}", 12f, muted, true).apply { setPadding(0, dp(10), 0, dp(20)) })
        box.addView(text("The game controls the next step.\nWaiting for the next game phase…", 13f, cream).apply { setLineSpacing(dp(6).toFloat(), 1f) })
        val back = makeButton("RETURN TO SCANNER", panel2, gold) { disconnect(false); openScanner() }
        box.addView(back, LinearLayout.LayoutParams(dp(210), dp(44)).apply { topMargin = dp(22) })
        stage.addView(box, FrameLayout.LayoutParams(-1, -1))
    }

    private fun makeButton(label: String, color: Int, fg: Int, click: () -> Unit): TextView = text(label, 11f, fg, true).apply {
        card(this, color, 9f); setPadding(dp(10), dp(6), dp(10), dp(6)); setOnClickListener { click() }
    }

    private fun selectFighter(f: Fighter) {
        selected = f.id
        io.execute {
            try {
                val response = request("POST", "/api/select", JSONObject().put("token", token).put("fighter_id", f.id))
                main.post {
                    if (response.optBoolean("ok")) { vibrate(22); refreshStage() }
                    else Toast.makeText(this, "Selection unavailable: ${response.optString("error")}", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) { main.post { Toast.makeText(this, "Connection lost", Toast.LENGTH_SHORT).show() } }
        }
    }

    private fun refreshStage() {
        val stage = root?.getChildAt(0)
        if (stage is LinearLayout && stage.childCount >= 2) {
            val maybe = stage.getChildAt(1)
            if (maybe is FrameLayout) renderPhase(maybe)
        } else buildController()
    }

    private fun startInput() {
        stopInput()
        main.post(sendRunnable)
        main.post(statusRunnable)
    }
    private val sendRunnable = object : Runnable {
        override fun run() {
            if (token.isBlank() || currentScreen != "controller") return
            if (sendBusy.compareAndSet(false, true)) io.execute {
                try {
                    val body = JSONObject().put("token", token).put("seq", ++seq).put("bits", bits).put("ax", ax).put("ay", ay)
                    val response = request("POST", "/api/input", body)
                    if (response.optBoolean("ok")) response.optJSONObject("hud")?.let { applyHud(it) }
                } catch (_: Exception) { main.post { statusText?.text = "RECONNECTING…"; statusText?.setTextColor(red) } }
                finally { sendBusy.set(false) }
            }
            main.postDelayed(this, 33)
        }
    }
    private val statusRunnable = object : Runnable {
        override fun run() {
            if (token.isBlank() || currentScreen != "controller") return
            io.execute {
                try {
                    val result = request("GET", "/api/status?token=${Uri.encode(token)}")
                    if (result.optBoolean("ok")) {
                        result.optJSONObject("hud")?.let { applyHud(it) }
                        val fromServer = result.optString("selected_fighter", "")
                        if (fromServer.isNotBlank()) selected = fromServer
                    }
                } catch (_: Exception) { }
            }
            main.postDelayed(this, 500)
        }
    }
    private fun stopInput() { main.removeCallbacks(sendRunnable); main.removeCallbacks(statusRunnable); bits = 0; ax = 0; ay = 0 }

    private fun applyHud(next: JSONObject) {
        main.post {
            hud = next
            val newPhase = next.optString("phase", phase)
            val events = next.optJSONArray("events") ?: JSONArray()
            for (i in 0 until events.length()) {
                val e = events.optJSONObject(i) ?: continue
                when (e.optString("type")) { "round_win" -> lastResult = "win"; "round_loss" -> lastResult = "loss" }
            }
            if (newPhase != phase) { if (newPhase == "fight") lastResult = ""; phase = newPhase; lastHudSignature = "" }
            val sig = "$phase|$selected|$lastResult"
            updateHudStats()
            statusText?.text = if (phase == "fight") "IN MATCH · PLAYER $player" else "CONNECTED · PLAYER $player"
            statusText?.setTextColor(green)
            if (sig != lastHudSignature) { lastHudSignature = sig; refreshStage() }
        }
    }

    private fun updateHudStats() {
        val hp = hud.optInt("hp", 0); val hm = hud.optInt("hp_max", 100).coerceAtLeast(1)
        val ohp = hud.optInt("opp_hp", 0); val ohm = hud.optInt("opp_hp_max", 100).coerceAtLeast(1)
        ownBar?.max = hm; ownBar?.progress = hp.coerceIn(0, hm); oppBar?.max = ohm; oppBar?.progress = ohp.coerceIn(0, ohm)
        ownHpText?.text = "$hp / $hm"; oppHpText?.text = "$ohp / $ohm"
    }

    private fun request(method: String, path: String, body: JSONObject? = null): JSONObject {
        val conn = (URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 2200; readTimeout = 2200; useCaches = false
            setRequestProperty("Accept", "application/json")
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8") }
        }
        try {
            if (body != null) conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            return JSONObject(raw)
        } finally { conn.disconnect() }
    }

    private fun disconnect(clear: Boolean) {
        stopInput()
        if (clear && token.isNotBlank()) io.execute { try { request("POST", "/api/leave", JSONObject().put("token", token)) } catch (_: Exception) { } }
        token = ""; selected = ""; lastResult = ""
        getSharedPreferences("astra", MODE_PRIVATE).edit().clear().apply()
    }
    private fun vibrate(ms: Long) {
        try { val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator; if (android.os.Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, 55)) else { @Suppress("DEPRECATION") v.vibrate(ms) } } catch (_: Exception) { }
    }

    inner class JoystickView(ctx: Context, val onAxis: (Int, Int) -> Unit) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var dx = 0f; private var dy = 0f; private var active = false
        override fun onDraw(c: Canvas) {
            super.onDraw(c); val cx = width / 2f; val cy = height / 2f; val radius = min(width, height) * .36f
            p.style = Paint.Style.FILL; p.color = Color.rgb(23, 24, 28); c.drawCircle(cx, cy, radius * 1.25f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2).toFloat(); p.color = Color.rgb(105, 86, 54); c.drawCircle(cx, cy, radius * 1.25f, p)
            p.strokeWidth = dp(1).toFloat(); p.color = Color.rgb(62, 59, 53); c.drawCircle(cx, cy, radius * .62f, p)
            p.style = Paint.Style.FILL; p.color = if (active) gold else Color.rgb(126, 105, 70)
            c.drawCircle(cx + dx, cy + dy, radius * .43f, p)
            p.color = Color.argb(55, 255, 255, 255); c.drawCircle(cx + dx - radius * .1f, cy + dy - radius * .1f, radius * .22f, p)
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            val cx = width / 2f; val cy = height / 2f; val r = min(width, height) * .36f
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    var x = e.x - cx; var y = e.y - cy; val len = sqrt(x*x + y*y); val limit = r * .78f
                    if (len > limit) { x *= limit / len; y *= limit / len }
                    dx = x; dy = y; active = true
                    fun axis(v: Float): Int { val n = (v / limit).coerceIn(-1f, 1f); val dz = .12f; val a = abs(n); val z = if (a <= dz) 0f else (a - dz) / (1f - dz) * if (n < 0) -1 else 1; return (z * 100).toInt() }
                    onAxis(axis(dx), axis(dy)); invalidate(); return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { dx = 0f; dy = 0f; active = false; onAxis(0, 0); invalidate(); return true }
            }
            return true
        }
    }

    inner class ActionPad(ctx: Context, private val label: String, private val fill: Int, val onPress: (Boolean) -> Unit) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var down = false
        override fun onDraw(c: Canvas) {
            val rr = RectF(2f, 2f, width - 2f, height - 2f)
            p.color = if (down) gold else fill; p.style = Paint.Style.FILL; c.drawRoundRect(rr, dp(13).toFloat(), dp(13).toFloat(), p)
            p.color = if (down) Color.rgb(12, 12, 13) else Color.rgb(83, 72, 55); p.style = Paint.Style.STROKE; p.strokeWidth = dp(1).toFloat(); c.drawRoundRect(rr, dp(13).toFloat(), dp(13).toFloat(), p)
            p.style = Paint.Style.FILL; p.color = if (down) bg else cream; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); p.textSize = dp(13).toFloat()
            c.drawText(label, width / 2f, height / 2f - (p.ascent() + p.descent()) / 2f, p)
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { down = true; onPress(true); invalidate(); return true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { down = false; onPress(false); invalidate(); performClick(); return true }
            }; return true
        }
        override fun performClick(): Boolean { super.performClick(); return true }
    }
}

# ASTRAVYUHA — build contracts (internal)

Every workstream (sprites, arenas/UI art, audio, phone bridge, GDScript game) must agree on
the formats below. Source of truth for gameplay data: `tools/data_gen/roster_def.py`
(emits `data/*.json`). Do **not** edit `data/*.json` by hand; edit the .py and re-run it.

## 0. Global numbers
* Internal game resolution: **480x270** art pixels. The Godot window base size is 960x540,
  the fight world is drawn at an integer **2x** scale (nearest filtering, no smoothing).
* World (stage) width **800** art px, height 270. Playable x range 40..760. Camera shows 480 px,
  so camera x ranges 0..320.
* Depth lane: fighters stand between y=204 (back/upstage) and y=238 (front/downstage) in art px.
  Art must show a readable floor band covering at least y=196..250.
* 60 combat ticks per second.

## 1. Fighter sprite sheets (tools/asset_generation/make_sprites.py)
Output per fighter `<id>` (ids: viraksha mrinala ketuman karkati aranyak sharvan tamrini nirvay):
* `assets/characters/<id>/sheet_default.png`, `sheet_pal.png` (uses `palette_alt` overrides
  from fighters.json), `sheet_gilt.png` (uses `weapon_alt` overrides). Same layout in all three.
* `assets/characters/<id>/anim.json`
* Frames are **256x256** (changed from 128 because weapons clipped), character faces **right**, feet origin at pixel **(96,208)** of the
  frame. Standing figure about 88 px tall (all fighters comparable height; Ketuman/Tamrini
  broader, Karkati/Mrinala narrower). One animation per **row**; row r starts at y = r*256;
  frame i at x = i*256. Transparent background, 1px dark outline, 3-tone shading.

```json
{ "frame_size":[128,128], "origin":[64,120],
  "anims": { "idle": {"row":0,"frames":4,"fps":6,"loop":true},
             "light": {"row":9,"frames":5,"fps":60,"loop":false,
                       "timeline":[{"from":0,"frame":0},{"from":3,"frame":1},{"from":5,"frame":2},{"from":8,"frame":3},{"from":11,"frame":4}]} } }
```
`timeline` (attack animations only) says: from combat tick `from` (counted from the first tick
of the attack) show frame `frame`; hold until the next entry; hold the last entry afterwards.
The generator must derive timelines from `data/fighters.json` attack frame data so that the
strike/extended frame is shown during the active ticks, wind-up frames before, follow-through
and recovery frames after. Multi-hit specials need >= 8 frames covering the five stages in the brief.

Required animation names (all fighters): `idle`(4 loop) `walk`(6 loop) `walk_back`(6 loop)
`crouch`(2; frame1 = held crouch) `crouch_block`(1) `block`(2; frame1 = held guard)
`jump_up`(1) `jump_air`(1) `jump_fall`(1) `land`(2) `hit`(2) `hit_low`(2) `hit_air`(1)
`guard_break`(2) `knockdown`(4; ends lying on ground) `lying`(1) `getup`(3) `evade`(3)
`light` `heavy` `crouch_attack` `air_attack` `special` (timeline-driven; names match the
attack kinds: light, heavy, crouch->`crouch_attack`, air->`air_attack`, special)
`victory`(6) `defeat`(4; last frame = defeated pose, held) `select`(4 loop).
(Aranyak `heavy` must show draw, aim and release of the bow; the arrow is a separate projectile.)

Portraits (same script, from the same palettes/accessories, drawn larger than sprites):
* `assets/portraits/<id>_portrait.png` 256x256 (character select, bio panel) — head/shoulders
  with weapon silhouette, painted backdrop in the fighter palette, ornamental frame.
* `assets/portraits/<id>_icon.png` 64x64 (HUD icon).
* `assets/portraits/<id>_versus.png` 256x384 transparent full-height bust for the versus screen.

Effects (tools/asset_generation/make_effects.py):
* `assets/effects/effects.json` + sheets. Format:
  `{ "<name>": {"file":"fx_<name>.png","frames":6,"fps":24,"size":[64,64],"loop":false} }`
  (horizontal strip, each frame `size`, anchor = frame centre, drawn facing right).
* Names that must exist: every `fx` and `tell.fx` and projectile `fx` used in data/fighters.json
  (slash, slash_heavy, slash_small, slash_low, slash_sweep, slash_counter, crescent, crescent_big,
  blunt, blunt_heavy, blunt_small, blunt_low, thrust, thrust_heavy, thrust_low, shockwave_dust,
  ember_burst, ash_wave, leaf_sweep, arrow_release, arrow_hit, glint, glint_gold, glint_silver,
  dust_gather, shadow_step, leaf_gather, ember_gather, ash_gather) plus `hit_spark`, `block_spark`,
  `perfect_guard`, `guard_break`, `ko_flash`, `dust_land`, and `arrow` (projectile sprite, 1 frame).
  Restrained: no effect may be larger than ~96x96 art px or hide the fighters.

## 2. Arenas (tools/asset_generation/make_arenas.py)
Directory `assets/arenas/<id>/` for ids `sabha`, `naga_ghat`, `vajra_durg`:
* `meta.json`:
```json
{ "id":"sabha", "floor_top":196,
  "layers":[ {"file":"layer_far.png","parallax":0.15,"frames":1,"fps":0,"y":0},
             {"file":"layer_mid.png","parallax":0.40,"frames":1,"fps":0,"y":0},
             {"file":"layer_near.png","parallax":1.0,"frames":4,"fps":3,"y":0},
             {"file":"layer_fore.png","parallax":1.25,"frames":1,"fps":0,"y":0,"foreground":true} ],
  "ambient": {"type":"dust|fireflies|rain", "count":40, "color":"#e6c88a"},
  "lightning": {"enabled":false},
  "tint_shadow":"#00000040" }
```
* Layer image size: width = `ceil(480 + 320*parallax)` or more (near layer = 800, fore >= 896);
  height = 270 * frames (animated layers are stacked vertically, one frame per 270 px).
* `layer_fore.png` must be sparse, mostly transparent, and only in the outer 40 px bands and
  the very bottom ( y>=250 ) so it never covers fighters or attacks.
* `preview.png` 320x180 (selection screen).
* Arena I palette sandstone/bronze/gold/brown/crimson; II deep green/blackened stone/turquoise/
  silver/amber; III charcoal/blue-grey/iron/indigo/pale lightning. See data/arenas.json.
  Lightning arena: provide `layer_flash.png` (same size as near layer, white-blue overlay used
  during flashes) and set `"lightning":{"enabled":true,"min_gap":240,"max_gap":720}` (ticks).

UI art (tools/asset_generation/make_ui.py) -> `assets/ui/`:
`logo.png` (about 560x140 ASTRAVYUHA wordmark, ornate gold on transparent), `menu_bg.png` (480x270),
`stone_tile.png` (64x64 seamless), `coin.png` (24x24 Vijaya Mark), `divider.png` (256x12),
`corner.png` (24x24), `emblem_<id>.png` 48x48 for lotus wheel serpent peacock trident sun
(ids `emb_lotus`... as in cosmetics.json -> file `emblem_lotus.png` etc.),
`victory_<petals|embers|dust|storm>.png` 48x48, `weapon_<khanda|twin_blades|gada|hooked_blade|bow|spear|hammer|staff_blade>.png` 48x48,
`lock.png` 24x24, `arrow_left.png`/`arrow_right.png` 24x24.

## 3. Audio (tools/asset_generation/make_audio.py) -> `assets/audio/*.wav`
16-bit PCM mono WAV, 22050 Hz (music may be 22050 too). No external samples; pure numpy synthesis.
SFX names: ui_move ui_select ui_back ui_error ui_purchase ui_unlock swing_light swing_blade
swing_heavy spear_thrust bow_release arrow_hit hit_light hit_heavy hit_special block
perfect_guard guard_break knockdown gada_impact hammer_impact shockwave clash round_start fight
ko time_up victory defeat tournament_advance evade jump land step special_ready
and per fighter `voice_<id>_attack`, `voice_<id>_hurt`, `voice_<id>_win` (short synthesized
vocal/breath gestures; each fighter audibly different).
Music (seamless loops, 24-40 s): `music_menu` (ASTRAVYUHA motif), `music_sabha`, `music_naga`,
`music_vajra`; plus non-looping `music_versus` (3 s stinger), `music_results` (6 s),
`ambient_rain` (loop). Directions: sabha = low drone + restrained cinematic percussion; naga =
drones, sparse bells, water; vajra = deep drums, storm, low-frequency accents. Original only.
Write `assets/audio/audio.json`: `{ "<name>": {"loop":true|false,"gain":0.8} }`.

## 4. Phone bridge (local_bridge/, phone_controller/)
Python stdlib only. `python local_bridge/bridge_server.py --port 8765 --admin-key KEY --pin 1234
[--bind 0.0.0.0] [--controller-dir phone_controller] [--portraits-dir assets/portraits]`
Static (LAN): `/` -> index.html, `/controller.css`, `/controller.js`, `/portraits/<id>_portrait.png`
(ids whitelisted, `*_portrait.png` and `*_icon.png` only). Nothing else is ever served.
Requests from non-private/non-loopback source IPs are rejected (403) so a port-forward cannot expose it.

Phone endpoints (JSON in/out, body <= 1 KB):
* `POST /api/join` `{"pin":"1234","slot":0|1|2,"token":"<optional>","name":"<label>"}`
  -> `{"ok":true,"player":1|2,"token":"<random>","resumed":bool}`; errors `bad_pin`(403)
  `slot_taken`(409) `full`(409). slot 0 = auto (first free). A valid `token` resumes its slot.
* `POST /api/input` `{"token":..,"seq":int,"bits":int,"ax":int,"ay":int}` ->
  `{"ok":true,"player":n,"hud":{...game hud...}}`. bits: 1 jump, 2 light, 4 heavy, 8 block,
  16 evade, 32 special. `ax`/`ay` -100..100 (ax>0 right, ay>0 downstage/down, ay<0 upstage).
  Out-of-range/ill-typed values are rejected 400; stale `seq` is ignored.
* `POST /api/leave` `{"token"}`;  `GET /api/status?token=..` -> same `hud`.

Game endpoints (loopback only AND header `X-Admin-Key`):
* `GET /api/game/poll` -> `{"server_time":ms,"players":{"1":{"connected":bool,"bits":int,"ax":int,"ay":int,"latched":int,"age_ms":int,"name":str,"seq":int},"2":{...}}}`.
  `latched` = OR of all bits pressed since the previous poll (so very short taps are not lost);
  cleared by the poll. If a player's last input is older than **300 ms**, `bits`/`ax`/`ay` are
  reported as 0 (input expiry). `connected` becomes false after **3000 ms** of silence; the slot
  stays reserved for its token for 60 s, then frees.
* `POST /api/game/hud` `{"phase":"menu|select|fight|results","players":{"1":{...},"2":{...}}}`
  per-player hud object (<= 2 KB each): `fighter_id name title hp hp_max meter meter_max
  special_ready opp_name opp_hp opp_hp_max wins opp_wins round time match_state events[]`
  where `events` is a list of `{"id":int,"type":"hit_landed|hit_taken|blocked|blocked_by|ko|round_win|round_loss"}`.
  The bridge stores it and returns it inside `/api/input` responses for that player.
* `GET /api/game/info` -> `{"port":8765,"pin":"1234","ips":["192.168.1.20",...],"urls":["http://192.168.1.20:8765/?pin=1234"],"players":{...}}`
* `GET /api/game/qr?text=<url>` -> `{"size":N,"rows":["0101...","..."]}` (1 = dark module)
* `POST /api/game/kick` `{"player":1|2}`; `POST /api/game/reset`.

Phone controller (phone_controller/index.html, controller.css, controller.js): see brief;
sends `POST /api/input` at ~30 Hz (and immediately on change), uses Pointer Events with one
independent pointer per control (multi-touch), never reports "hit" itself — only shows
HIT / BLOCKED flashes from `hud.events`. Settings persisted in localStorage.

## 5. Save file (Godot `user://astravyuha_save.json`)
See scripts/save/save_manager.gd. Versioned (`"version": 1`), backup `user://astravyuha_save.bak`.

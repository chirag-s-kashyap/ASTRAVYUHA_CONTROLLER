# Get the APK without installing Android Studio

This project includes a GitHub Actions workflow that builds the APK on a hosted GitHub runner.

## Steps

1. Sign in to GitHub and create a **new empty repository** (for example `ASTRAVYUHA-Android-Controller`).
2. Upload the *contents* of this project folder to the repository. Keep the `.github/workflows/build-apk.yml` file and its folder structure intact.
3. Open the repository's **Actions** tab. The workflow named **Build ASTRAVYUHA Android APK** should start after the first push. If it does not, open it and choose **Run workflow**.
4. Wait for the run to finish successfully.
5. Open the completed run and download the artifact named **ASTRAVYUHA-Controller-debug-apk**.
6. Extract the artifact on your phone or computer. Install `app-debug.apk` on Android. If Android asks, allow installation from that source.

No Android Studio installation is needed. GitHub builds the APK using Java 17, Gradle 8.7 and Android SDK 35.

## Notes

- This produces a debug-signed APK for personal testing, not a Play Store release.
- The phone and game PC must be on the same Wi-Fi network and the PC bridge must be running.
- This workflow has not been executed in this environment. A successful GitHub Actions run is required before treating the APK as built and installable.

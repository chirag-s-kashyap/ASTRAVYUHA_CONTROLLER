# ASTRAVYUHA Controller — Native Android

Standalone Android application source for the existing ASTRAVYUHA PC game's phone-controller bridge. This project does **not** modify the Godot game or replace the Python bridge.

## Compatibility verified against the supplied game archive

The app uses the existing phone-side HTTP contract:

- `POST /api/join` — PIN + auto player slot, receives the player token.
- `POST /api/input` — sends `token`, increasing `seq`, `bits`, `ax`, `ay` at ~30 Hz.
- `GET /api/status?token=...` — reads phase, HUD and selected fighter.
- `POST /api/select` — selects one of the game's eight fighter IDs.
- `POST /api/leave` — releases the phone slot.

Combat bit flags are unchanged: jump `1`, light `2`, heavy `4`, block `8`, evade `16`, special `32`. Axes remain `-100..100`; positive X is right and positive Y is downstage. The eight portraits are copied from the supplied game's `assets/portraits` folder.

## App experience

- Native Android Activity, forced landscape, immersive full-screen and screen kept awake.
- ASTRAVYUHA logo splash, then a native CameraX + ML Kit QR scanner.
- QR URL parsing automatically extracts the PC host, port and `pin` query parameter.
- Manual host/PIN fallback if camera access is unavailable.
- Auto player-slot join, token persistence, live input transmission and 500 ms HUD polling.
- 4-column × 2-row selection grid using the actual game portraits.
- Landscape combat layout with multi-touch joystick and six independent action pads.
- Victory/defeat state from the bridge's `round_win` / `round_loss` events and results phase.
- Haptic feedback on action presses.

## Build an APK

This workspace does not have the Android SDK / Android Gradle build tools installed, so an APK could not be compiled or signed here. The complete Android Studio project is included.

1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this `ASTRAVYUHA_Android` folder in Android Studio.
3. Allow Gradle sync to download the Android Gradle Plugin and dependencies.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

For a release APK, configure your own signing key in Android Studio's Generate Signed Bundle / APK wizard.

## Pairing

1. Start the game and its existing Phone Controllers bridge on the PC.
2. Connect the Android phone and PC to the same Wi-Fi network.
3. Open ASTRAVYUHA Controller and scan the QR shown by the game. The app also accepts the bridge URL and PIN manually.
4. The app joins the first free player slot and enters the controller UI.

If Android or a router blocks local traffic, allow the game/Python bridge through the PC firewall on the Private network and disable client/AP isolation on the Wi-Fi router.

## Existing protocol boundaries (intentionally not faked)

The supplied bridge contract has no cursor-position / mouse-click endpoint and no rematch endpoint. Fighter selection is accepted only in the bridge's `menu` or `setup` phases. The app therefore does not display nonfunctional touchpad, rematch, or post-result character-change controls. Those capabilities require an extension to the PC-side bridge/game, which this deliverable deliberately does not modify.
